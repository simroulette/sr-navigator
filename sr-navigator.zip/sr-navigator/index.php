<?
// ===================================================================
// Sim Roulette -> INDEX
// License: GPL v3 (http://www.gnu.org/licenses/gpl.html)
// Copyright (c) 2016-2020 Xzero Systems, http://sim-roulette.com
// Author: Nikita Zabelin
// ===================================================================

include("_func.php");
sr_header("SR Navigator");
?>
<br>Панель управления СИМ-агрегаторами SIM Roulette
<?
sr_footer();
?>